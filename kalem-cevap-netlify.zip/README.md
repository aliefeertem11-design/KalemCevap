# Kalem Cevap

PDF yüklenir. Cevaplar PDF'in cevap alanlarına siyah kalemle yazılmış gibi eklenir ve cevaplı PDF indirilir.
Siteyi kullanan kişinin giriş yapması gerekmez.

## Klasörler

- `public/` sitenin kendisi (index.html ve el yazısı fontu)
- `netlify/edge-functions/answer.js` API anahtarını gizli tutan sunucu parçası
- `netlify.toml` Netlify ayarı

## Kurulum

1. https://aistudio.google.com/apikey adresine Google hesabınla gir. Create API key de. Ücretsizdir ve kart istemez.
2. https://github.com adresinde yeni bir depo aç. Örnek ad: kalem-cevap.
3. "uploading an existing file" bağlantısına tıkla. Bu klasörün İÇİNDEKİ her şeyi sürükle. Yani `public`, `netlify` ve `netlify.toml`. Commit changes de.
4. https://app.netlify.com adresine GitHub ile giriş yap.
5. Add new project. Import an existing project. GitHub. Depoyu seç.
6. Ayarlara dokunma. Deploy de.
7. Project configuration. Environment variables. Add a variable:
   - Key `GEMINI_API_KEY` Value senin anahtarın.
   - İstersen Key `ACCESS_CODE` Value bir şifre. Böylece sadece kodu bilenler kullanır.
8. Deploys. Trigger deploy. Deploy project without cache.
9. Netlify'ın verdiği link artık her cihazda çalışır. Site configuration kısmından adını değiştirebilirsin.

## Ücret

GitHub, Netlify ve Gemini ücretsiz kotası ile para ödemeden çalışır.
Ücretsiz kotanın günlük bir sınırı var. Sınır dolunca site ertesi güne kadar "Çok fazla istek oldu" der.
Linki herkese açacaksan ACCESS_CODE koy ki kotanı başkaları bitirmesin.
Model değiştirmek için `MODEL` değişkeni eklenebilir. Varsayılan `gemini-flash-latest`.
